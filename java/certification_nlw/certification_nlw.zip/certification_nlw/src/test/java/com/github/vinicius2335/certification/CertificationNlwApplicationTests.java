package com.github.vinicius2335.certification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertificationNlwApplicationTests {

	@Test
	void contextLoads() {
	}

}
